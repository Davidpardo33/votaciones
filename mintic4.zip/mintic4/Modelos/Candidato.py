from Modelos.AbstractModelo import AbstractModelo
class Candidato(AbstractModelo):
    pass