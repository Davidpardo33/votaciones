from Repositorios.InterfaceRepositorio import InterfaceRepositorio
from Modelos.Resultado import Resultado
class RepositorioResultado(InterfaceRepositorio[Resultado]):
    pass