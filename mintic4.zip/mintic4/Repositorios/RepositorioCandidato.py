from Repositorios.InterfaceRepositorio import InterfaceRepositorio
from Modelos.Candidato import Candidato
class RepositorioCandidato(InterfaceRepositorio[Candidato]):
    pass